import 'regenerator-runtime'; /* for async await transpile */
import '../styles/style.css';
import './navbar.js';
import './resto-list.js';